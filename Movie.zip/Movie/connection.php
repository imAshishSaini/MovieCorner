<?php

$server = "localhost";
$username = "root";
$password = "";
$db = "moviecorner";

$conn = mysqli_connect($server, $username, $password, $db);

?>